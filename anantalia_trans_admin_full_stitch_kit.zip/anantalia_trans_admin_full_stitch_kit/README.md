# Anantalia Trans Admin — Google Stitch Kit

Paket ini berisi brief untuk merancang **seluruh 10 halaman Admin Panel**, bukan hanya Dashboard Overview.

## Isi
- `stitch_prompt.md` — prompt utama siap ditempel ke Google Stitch.
- `design_system.md` — design tokens dan komponen bersama.
- `screen_spec.md` — spesifikasi rinci seluruh halaman, state, dan interaksi.
- `assets/README.md` — petunjuk aset logo.

## Cara menggunakan
1. Buka Google Stitch.
2. Lampirkan screenshot TailAdmin yang menjadi referensi layout.
3. Lampirkan logo resmi Anantalia Trans (`logo.png`) bila tersedia.
4. Tempel isi `stitch_prompt.md`.
5. Gunakan `design_system.md` dan `screen_spec.md` sebagai acuan evaluasi/iterasi.
6. Pastikan semua 10 halaman dibuat dan prototype navigasinya saling terhubung.

## Penting
File Markdown adalah prompt dan spesifikasi kerja, bukan file proyek Stitch native.
Paket ini belum berisi logo resmi karena file logo tidak disertakan pada upload terakhir. Prompt menginstruksikan Stitch memakai slot logo sementara yang dapat diganti, bukan menggambar ulang logo.
