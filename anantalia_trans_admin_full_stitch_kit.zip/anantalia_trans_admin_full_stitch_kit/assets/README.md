# Assets

Tempatkan aset resmi Anantalia Trans di folder ini sebelum melampirkannya ke Google Stitch.

## Logo
- Nama file yang disarankan: `logo.png`
- Gunakan logo resmi yang sudah ada di project.
- Pertahankan rasio aspek dan desain asli.
- Jangan redraw, recolor, crop secara agresif, atau mengganti logo.
- Bila logo belum tersedia, gunakan placeholder sementara di desain dan ganti setelah aset resmi dilampirkan.

Catatan: folder ini belum berisi logo karena file logo tidak ikut diunggah pada permintaan terakhir.
